#!/usr/bin/with-contenv bash
# Use this script to write / replace the goldnugget to the correct place.
# The goldnugget is available as $GOLDNUGGET.

echo $GOLDNUGGET > /flag.txt