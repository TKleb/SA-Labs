#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#define MAX 40

int main(int argc, char **argv)
{
	char buf[MAX], pass1[MAX], pass2[MAX];
	char *pass;
	int len;

	printf("How long password would you like to set? ");
	fflush(stdout);
	fgets(buf, MAX, stdin);
	sscanf(buf, "%d", &len);

	printf("Ok, please enter your %d-character password: ", len);
	fflush(stdout);
	fgets(pass1, len, stdin);

	printf("Retype for confirmation: ");
	fflush(stdout);
	fgets(pass2, len, stdin);

	if (strncmp(pass1, pass2, len))
	{
		printf("Passwords don't match: \n");
		write(1, pass1, len);
		putchar('\n');
		write(1, pass2, len);
		exit(0);
	}

	printf("Saved.\n");

	if ((pass=getenv("PASSWORD")) && argc == 2)
	{
		int plen = strlen(pass);
		if (!strncmp(pass1, pass, (len < plen) ? len : plen)) {
			FILE *fp = fopen(argv[1], "r");
			if(fp)
			{
				fgets(buf, MAX, fp);
				puts(buf);
				fclose(fp);
			}
		}
	}
	exit(0);
}


