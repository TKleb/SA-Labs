#!/usr/bin/with-contenv bash
# Use this script to write / replace the goldnugget to the correct place.
# The goldnugget is available as $GOLDNUGGET.

cd /compile

export FLAG=$(echo $GOLDNUGGET | cut -c 1-31)
echo $GOLDNUGGET | cut -c 1-31 > /flag.txt
MYUUID=$(echo $GOLDNUGGET | cut -c 32-36)

sed -i -e "s/MYUUID/$MYUUID/g" /opt/www/index.html

gcc -O0 server.c -o server
cp server /opt/www
