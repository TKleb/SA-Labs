#!/bin/sh
sudo /usr/sbin/unitd --log /dev/stderr
/server
