#include <stdio.h>
#include <signal.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 1345

int main(int argc, char **argv)
{
	struct sockaddr_in server;
	struct sockaddr_in client;
	int l = sizeof(struct sockaddr_in);
	int sock, csock;
	const char *msg = "How many random bytes do you need? (Enter negative number to exit) ";
	struct {
		char buf[32];
		int fd1, fd2;
	} data;

	data.fd1 = open("/dev/urandom", O_RDONLY);
	data.fd2 = open("/flag.txt", O_RDONLY);

	sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &(int){1}, sizeof(int));
	memset((char *)&server, 0, sizeof(server));
	server.sin_family = AF_INET;
	server.sin_addr.s_addr = htonl(INADDR_ANY);
	server.sin_port = htons(PORT);

	if (bind(sock, (struct sockaddr *)&server, sizeof(server)) == -1) {
		perror("bind");
		close(sock);
		exit(1);
	}
	fprintf(stderr, "Challenge server listening at %d\n", PORT);

	listen(sock, 3);

	l = sizeof(struct sockaddr_in);
	csock = accept(sock, (struct sockaddr *)&client, (socklen_t *)&l);

	if(csock > 0) {
		close(STDIN_FILENO);
		close(STDOUT_FILENO);

		dup2(csock, STDIN_FILENO);
		dup2(csock, STDOUT_FILENO);

		setbuf(stdout, 0);

		write(1, msg, strlen(msg));
		read(0, &data.buf, strlen(msg));
		read(data.fd1, &data.buf, atoi(data.buf));
		write(1, data.buf, sizeof(data.buf));
		close(csock);
	}

	close(sock);
	close(data.fd1);
	close(data.fd2);
	exit(0);
}

