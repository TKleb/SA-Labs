#!/usr/bin/env python3
from Crypto.Cipher import AES
from secrets import randbelow, token_bytes
from random import sample
from sys import stdin, stdout
from flag import m

p = token_bytes(16)
q = token_bytes(16)
n = randbelow(len(m) // 16 - 1) + 1

xor = lambda s, t: b''.join(bytes([a ^ b]) for a, b in zip(s, t))
aes = lambda s: AES.new(p, AES.MODE_CBC, b'\x00'*16).encrypt(s)
lst = lambda s: [s[i:i+16].ljust(16, b'\x00') for i in range(0, len(s), 16)]
inc = lambda s, t: bytes.fromhex("%032x" % (int(s.hex(), 16) + (t % n)))
blk = lambda s, t: b''.join(xor(aes(inc(t, i)), s[i]) for i in range(len(s)))
enc = lambda s, t: blk(lst(s), t)

f = enc(m, q)

while True:
    print("1 - Print encrypted flag")
    print("2 - Test encryption")
    print("3 - Quit")
    print("==> ", end='', flush=True)
    a = stdin.readline().strip()

    if a == '1':
        print("Here you go:", ''.join("{:02x}".format(c) for c in f))
    elif a == '2':
        print("Enter a hex-encoded message to encrypt: ", end='', flush=True)
        try:
            b = stdin.readline().strip()
            b = '0' * (len(b) % 2) + b
            e = enc(bytes.fromhex(b), q)
            s = ['1'] * len(p)
            t = bytearray(p)
            for i in sample(range(len(p) - 1), 3):
                s[i] = '0'
                t[i] = randbelow(256)
            print("Encryption key :", ''.join("{:02x}".format(c) for c in t))
            print("Mask of truth  :", ''.join(s))
            print("Your cryptogram:", ''.join("{:02x}".format(c) for c in e))
        except ValueError as e:
            print(e)
    elif a == '3':
        print("Thanks, bye!")
        exit(0)
    else:
        print("Invalid choice")
    print('')
