
# m is the message to be encrypted. 
# make sure it is at least 3*16 bytes long and contains the flag
flag = b"abcdefg12345678910"

m = b"""
Encryption is not an easy task. Even professionals fail sometimes.
There are issues with computers getting more powerful, but algorithms
may also contain flaws that go unnoticed for years, or even decades.
Implementing cryptography is not easy either. Developer must understand
the algorithm and toolset thoroughly. Hackers are very clever to use
all kinds of technologies, e.g., side channels - precise timing, 
measuring CPU heat dissipation or power supply noises - to break
cryptography. Novice programmers often make quite simple mistakes
when trying to implement their own cryptographic libraries.
This code is a good example. 

Your flag is """ + flag

assert len(m) > 32, "Message should be longer than 2 blocks for AES"
